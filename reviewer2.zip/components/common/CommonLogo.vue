<template lang="pug">
  nuxt-link(tag="img" src="/img/logo.svg" to="/").logo

</template>

<script>
export default {}
</script>

<style lang="sass" scoped>
.logo
  height: 44px
  cursor: pointer
</style>
